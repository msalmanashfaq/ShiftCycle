#include <shiftcycle.h>

// 595: STCP (latch), SHCP (clock), DS (data in)
// 165: PL (load), CP (clock), QH (data out)
// 1 chip = 8 inputs/outputs

ShiftCycle shift(10, 13, 11, 9, 8, 12, 1);

void setup() {
    Serial.begin(9600);
    shift.begin();
}

void loop() {
    shift.run();
}
