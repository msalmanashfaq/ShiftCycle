#include "shiftcycle.h"

ShiftCycle::ShiftCycle(uint8_t STCP, uint8_t SHCP, uint8_t DS,
                       uint8_t PL, uint8_t CP, uint8_t QH,
                       uint8_t numChips)
    : _STCP(STCP), _SHCP(SHCP), _DS(DS),
      _PL(PL), _CP(CP), _QH(QH),
      _numChips(numChips)
{
    _inputStates = new uint8_t[_numChips];
    _outputStates = new uint8_t[_numChips];
}

void ShiftCycle::begin() {
    pinMode(_STCP, OUTPUT);
    pinMode(_SHCP, OUTPUT);
    pinMode(_DS, OUTPUT);

    pinMode(_PL, OUTPUT);
    pinMode(_CP, OUTPUT);
    pinMode(_QH, INPUT);

    digitalWrite(_STCP, LOW);
    digitalWrite(_SHCP, LOW);
    digitalWrite(_PL, HIGH);
    digitalWrite(_CP, LOW);

    for (uint8_t i = 0; i < _numChips; i++) {
        _inputStates[i] = 0;
        _outputStates[i] = 0;
    }
}

void ShiftCycle::run() {
    updateInputs();

    for (uint8_t i = 0; i < _numChips; i++) {
        _outputStates[i] = _inputStates[i];
    }

    updateOutputs();
}

void ShiftCycle::updateInputs() {
    digitalWrite(_PL, LOW);
    delayMicroseconds(5);
    digitalWrite(_PL, HIGH);
    delayMicroseconds(5);

    for (uint8_t i = 0; i < _numChips; i++) {
        _inputStates[i] = shiftIn(_QH, _CP, MSBFIRST);
    }
}

void ShiftCycle::updateOutputs() {
    digitalWrite(_STCP, LOW);
    for (int8_t i = _numChips - 1; i >= 0; i--) {
        shiftOut(_DS, _SHCP, MSBFIRST, _outputStates[i]);
    }
    digitalWrite(_STCP, HIGH);
}
