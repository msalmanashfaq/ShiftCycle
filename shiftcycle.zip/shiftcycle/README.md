# ShiftCycle Library

This Arduino library reads inputs from 74HC165 shift registers and controls outputs on 74HC595 shift registers. It automatically maps each input pin to a corresponding output pin (1:1) for each chip.

## Features
- Supports multiple 74HC165 and 74HC595 chips
- Reads inputs and mirrors them to outputs
- Simple API: `begin()` and `run()`

## Example

```cpp
#include <shiftcycle.h>

ShiftCycle shift(10, 13, 11, 9, 8, 12, 1);

void setup() {
    shift.begin();
}

void loop() {
    shift.run();
}
```
