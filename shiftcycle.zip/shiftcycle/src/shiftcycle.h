#ifndef SHIFTCYCLE_H
#define SHIFTCYCLE_H

#include <Arduino.h>

class ShiftCycle {
public:
    ShiftCycle(uint8_t STCP, uint8_t SHCP, uint8_t DS,
               uint8_t PL, uint8_t CP, uint8_t QH,
               uint8_t numChips);

    void begin();
    void run();

private:
    void updateInputs();
    void updateOutputs();

    uint8_t _STCP, _SHCP, _DS;
    uint8_t _PL, _CP, _QH;
    uint8_t _numChips;
    uint8_t* _inputStates;
    uint8_t* _outputStates;
};

#endif
